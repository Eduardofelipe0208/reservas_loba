<?php

require_once "../controladores/usuarios.controlador.php";
require_once "../modelos/usuarios.modelo.php";

class AjaxUsuarios{

	/*=============================================
	VALIDAR cedula EXISTENTE
	=============================================*/	

	public $validarCedula;

	public function ajaxValidarCedula(){

		$item = "cedula";
		$valor = $this->validarCedula;

		$respuesta = ControladorUsuarios::ctrMostrarUsuario($item, $valor);

		echo json_encode($respuesta);

	}

}

/*=============================================
VALIDAR cedula EXISTENTE
=============================================*/	

if(isset($_POST["validarCedula"])){

	$valCedula = new AjaxUsuarios();
	$valCedula -> validarCedula = $_POST["validarCedula"];
	$valCedula -> ajaxValidarCedula();

}


