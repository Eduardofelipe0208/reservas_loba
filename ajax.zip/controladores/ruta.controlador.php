<?php

class ControladorRuta{

	static public function ctrRuta(){

		return "http://localhost/reservas-loba/";

	}

	static public function ctrServidor(){

		return "http://localhost/reservas-loba/backend/";
	}

}