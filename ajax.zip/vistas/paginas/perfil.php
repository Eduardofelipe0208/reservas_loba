<?php

if(isset($_SESSION["validarSesion"])){	


		include "modulos/banner-interior.php";
		include "modulos/info-perfil.php";
		

	 }else{

	echo '<script> window.location="'.$ruta.'"</script>';
}
