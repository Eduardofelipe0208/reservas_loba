<!--=====================================
TESTIMONIOS
======================================-->
<div class="testimonios container-fluid py-5 text-white">
	
	<div class="container mb-3">
			
		<h1 class="text-center py-5">TESTIMONIOS</h1>

		<div class="row">
			
			<div class="col-12 col-lg-3 text-center p-4">
				
				<img src="img/testimonio01.png" class="img-fluid rounded-circle">

				<h4 class="py-4">Lorem ipsum dolor</h4>

				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Expedita eveniet veniam, ut praesentium alias aut suscipit sed cupiditate quam ab totam autem, doloremque quasi. Temporibus, dicta. Odit labore dolore deleniti.</p>

			</div>

			<div class="col-12 col-lg-3 text-center p-4">
				
				<img src="img/testimonio02.png" class="img-fluid rounded-circle">

				<h4 class="py-4">Lorem ipsum dolor</h4>

				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Expedita eveniet veniam, ut praesentium alias aut suscipit sed cupiditate quam ab totam autem, doloremque quasi. Temporibus, dicta. Odit labore dolore deleniti.</p>

				
			</div>

			<div class="col-12 col-lg-3 text-center p-4">
				
				<img src="img/testimonio03.png" class="img-fluid rounded-circle">

				<h4 class="py-4">Lorem ipsum dolor</h4>

				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Expedita eveniet veniam, ut praesentium alias aut suscipit sed cupiditate quam ab totam autem, doloremque quasi. Temporibus, dicta. Odit labore dolore deleniti.</p>
				
			</div>

			<div class="col-12 col-lg-3 text-center p-4">
				
				<img src="img/testimonio04.png" class="img-fluid rounded-circle">

				<h4 class="py-4">Lorem ipsum dolor</h4>

				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Expedita eveniet veniam, ut praesentium alias aut suscipit sed cupiditate quam ab totam autem, doloremque quasi. Temporibus, dicta. Odit labore dolore deleniti.</p>
				
			</div>


		</div>

		<button class="btn btn-default float-right px-4">VER MÁS</button>

	</div>

</div>