<!--=====================================
BANNER-INTERIOR
======================================-->

<div class="bannerInterior container-fluid bg-white p-0 d-none d-lg-block">
	
	<figure>
		
		<img src="img/banner1.jpg" class="img-fluid" width="100%">

	</figure>

</div>